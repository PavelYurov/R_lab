﻿#include <iostream>
#include <stack>
#include <stdlib.h>


#include <algorithm>
#include <random>

#include<time.h>
#include<vector>


#include"quickhull algorithm/quickhull-master/quickhull_comp.hpp"


std::vector<quickhull::Vector3<double>>
convexHull(quickhull::Vector3<double>* Point3Ds) {
    if (Point3Ds == NULL) throw "wrong input";
    long long len = _msize(Point3Ds) / sizeof(quickhull::Vector3<double>);

    long long n = (long long)pow(2,pow(2, ceil(log(log(len)))));
    std::cout << std::endl << "n = " << n << std::endl;

    //std::cout << std::endl << "enter n: "; std::cin >> n;
    //uncomment to use manual input

    std::vector<quickhull::Vector3<double>> tmp_vect;
    quickhull::ConvexHull<double> hull;
    quickhull::VertexDataSource<double> tmp;

    long long len_tmp = len / n;
    long long len_tmp1 = 0;

    quickhull::QuickHull<double> qh;

    while (len_tmp1 + len_tmp <= len) {

        hull = qh.getConvexHull(&Point3Ds[len_tmp1], len_tmp, true, false);
        
        tmp = hull.getVertexBuffer();

        tmp_vect.insert(tmp_vect.end(), tmp.begin(), tmp.end());
        len_tmp1 += len_tmp;
    }
    for (long long i = len_tmp1; i < len; ++i) {
        tmp_vect.push_back(Point3Ds[i]);
    }

    
    hull = qh.getConvexHull(tmp_vect, true, false);
    tmp = hull.getVertexBuffer();
    return std::vector<quickhull::Vector3<double>>(tmp.begin(),tmp.begin() + tmp.size());
}

//======================================================


int main()
{
    srand(time(NULL));
    const int RANDVALUE = 10000;


    unsigned long long int len = 3;
    std::cout << "enter amount of 3d Point3Ds" << std::endl;
    std::cin >> len;
    quickhull::Vector3<double>* Point3Ds = new quickhull::Vector3<double>[len];


    

    for (unsigned long long int i = 0; i < len; ++i) {
        double x, y, z;

        //double  y = (rand() % RANDVALUE - RANDVALUE / 2) , x = (rand() % RANDVALUE - RANDVALUE / 2) , z = (rand() % RANDVALUE - RANDVALUE / 2);
        //uncomment to make random input

        std::cin >> x >> y >> z;
        Point3Ds[i] = { x, y,z };
    }
    
    std::cout << "The Point3Ds in the convex hull are: " << std::endl;
    float timer3 = std::clock();

    auto hull = convexHull(Point3Ds);

    std::cout << std::endl << "time: " << (float)(clock() - timer3) / CLOCKS_PER_SEC << std::endl;
    for (int i = 0; i < hull.size(); ++i) {
        std::cout << "( " << hull[i].x << " , " << hull[i].y << " , " << hull[i].z << " ) " << std::endl;
    }
    delete[]Point3Ds;
    return 0;
}


