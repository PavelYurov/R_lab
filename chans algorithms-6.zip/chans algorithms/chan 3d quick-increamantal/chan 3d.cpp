﻿#include <iostream>
#include <stack>
#include <stdlib.h>


#include <algorithm>
#include <random>

#include<time.h>
#include<vector>

#include"incremental algorithm/incremental.h"
#include"incremental algorithm/quickhull algorithm/quickhull-master/quickhull_comp.hpp"


template<class T>
void add_to_vector(std::vector<T>& H, const T& t) {
    for (int i = 0; i < H.size(); ++i) {
        if (H[i] == t) return;
    }
    H.push_back(t);
}

std::vector<quickhull::Vector3<double>>
convexHull(Point3D* Point3Ds) {
    if (Point3Ds == NULL) throw "wrong input";
    long long len = _msize(Point3Ds) / sizeof(Point3D);;

    long long n = (long long)ceil(pow(2, pow(2, log(log((len))))));
    std::cout << std::endl << "n = " << n << std::endl;

    //std::cout << std::endl << "enter n: ";
    //std::cin >> n;
    //uncomment for manual input
    

    std::vector<Point3D> tmp_vect;
    quickhull::ConvexHull<double> hull;
    quickhull::VertexDataSource<double> tmp;
    long long len_tmp = len / n;
    long long len_tmp1 = 0;

    quickhull::QuickHull<double> qh;

    while (len_tmp1 + len_tmp <= len) {

        hull = qh.getConvexHull(&Point3Ds[len_tmp1], len_tmp, true, false);
        len_tmp1 += len_tmp;
        tmp = hull.getVertexBuffer();

        tmp_vect.insert(tmp_vect.end(), tmp.begin(), tmp.begin() + tmp.size());
    }
    for (long long i = len_tmp1; i < len; ++i) {
        tmp_vect.push_back(Point3Ds[i]);
    }
    
    ConvexHull hull1(tmp_vect);
    auto faces = hull1.GetVertices();
    if (faces.size() != 0) {
        return faces;
    }
    else {
        hull = qh.getConvexHull(tmp_vect, true, false);
        tmp = hull.getVertexBuffer();
        return std::vector<Point3D>(tmp.begin(), tmp.begin() + tmp.size());
    }
}

//======================================================


int main()
{
    srand(time(NULL));
    const int RANDVALUE = 10000;


    unsigned long long int len = 0;
    std::cout << "enter amount of 3d Point3Ds" << std::endl;
    std::cin >> len;

    Point3D* Point3Ds = new Point3D[len];
    for (unsigned long long int i = 0; i < len; ++i) {
        double x, y, z;
        //double  y = (rand() % RANDVALUE - RANDVALUE / 2) , x = (rand() % RANDVALUE - RANDVALUE / 2) , z = (rand() % RANDVALUE - RANDVALUE / 2);
        //uncomment for random points

        std::cin >> x >> y >> z;
        Point3Ds[i]=Point3D(x, y, z);
    }
    
    std::cout << "The Point3Ds in the convex hull are: " << std::endl;
    float timer3 = std::clock();

    auto hull = convexHull(Point3Ds);

    std::cout << std::endl << "time: " << (float)(clock() - timer3) / CLOCKS_PER_SEC << std::endl;
    for (int i = 0; i < hull.size(); ++i) {
        std::cout << "( " << hull[i].x << " , " << hull[i].y << " , " << hull[i].z << " ) " << std::endl;
    }
    return 0;
}


