﻿#include <iostream>
#include <stack>
#include <stdlib.h>


#include <algorithm>
#include <random>

#include<time.h>
#include<vector>

#include"incremental algorithm/incremental.h"
#include"incremental algorithm/quickhull algorithm/quickhull-master/quickhull_comp.hpp"


std::vector<quickhull::Vector3<double>>
convexHull(Point3D* Point3Ds) {
    if (Point3Ds == NULL) throw "wrong input";
    long long len = _msize(Point3Ds) / sizeof(Point3D);
    if (len == 0) throw "0 points in object";
    long long n = (long long)ceil(pow(2,pow(2,log(log((len))))));

    //std::cout << std::endl << "enter n: ";
    //std::cin >> n;
    //uncomment for manual input


    std::cout << std::endl << "n = " << n << std::endl;

    std::vector<Point3D> tmp_vect;
    PointStack faces;
    long long len_tmp = len / n;
    long long len_tmp1 = 0;

    quickhull::QuickHull<double> qh;
    
    while (len_tmp1 + len_tmp <= len) {

        faces = ConvexHull(&Point3Ds[len_tmp1],len_tmp).GetVertices();
        
        
        
        if (faces.size() != 0) {
            tmp_vect.insert(tmp_vect.end(), faces.begin(), faces.end());
        }
        else {

            auto hull = qh.getConvexHull(&Point3Ds[len_tmp1], len_tmp, true, false);
            const auto& tmp = hull.getVertexBuffer();
            tmp_vect.insert(tmp_vect.end(), tmp.begin(), tmp.end());
        }
        len_tmp1 += len_tmp;
    }
    for (long long i = len_tmp1; i < len; ++i) {
        tmp_vect.push_back(Point3Ds[i]);
    }
    
    auto hull = qh.getConvexHull(tmp_vect, true, false);
    const auto& tmp = hull.getVertexBuffer();

    return std::vector<quickhull::Vector3<double>>(tmp.begin(), tmp.end());
}

//======================================================


int main()
{
    srand(time(NULL));
    const int RANDVALUE = 100;

   

    unsigned long long int len = 0;
    std::cout << "enter amount of 3d Point3Ds" << std::endl;
    std::cin >> len;
    Point3D* Point3Ds = new Point3D[len];
    for (unsigned long long int i = 0; i < len; ++i) {
        double x, y, z;
        //double  y = (rand() % RANDVALUE - RANDVALUE / 2) , x = (rand() % RANDVALUE - RANDVALUE / 2) , z = (rand() % RANDVALUE - RANDVALUE / 2);
        //uncomment for random input

        std::cin >> x >> y >> z;
        Point3Ds[i]=Point3D(x, y, z);
    }
    
    std::cout << "The Point3Ds in the convex hull are: " << std::endl;
    float timer3 = std::clock();

    auto hull = convexHull(Point3Ds);

    std::cout << std::endl << "time: " << (float)(clock() - timer3) / CLOCKS_PER_SEC << std::endl;
    for (int i = 0; i < hull.size(); ++i) {
        std::cout << "( " << hull[i].x << " , " << hull[i].y << " , " << hull[i].z << " ) " << std::endl;
    }
    delete[]Point3Ds;
    return 0;
}


