﻿#include <iostream>
#include <stack>
#include <stdlib.h>


#include <algorithm>
#include <random>

#include<time.h>
#include<vector>


struct Point
{
    double x;
    double y;
    Point(const double& inp_x, const double& inp_y) {
        x = inp_x; y = inp_y;
    }
    Point() {
        x = 0; y = 0;
    }
};

// A global point needed for  sorting points with reference
// to  the first point Used in compare function of qsort()
Point p0;

// A utility function to find next to top in a stack
Point nextToTop(std::stack<Point>& S)
{
    Point p = S.top();
    S.pop();
    Point res = S.top();
    S.push(p);
    return res;
}

// A utility function to swap two points
void swap(Point& p1, Point& p2)
{
    Point temp = p1;
    p1 = p2;
    p2 = temp;
}

// A utility function to return square of distance
// between p1 and p2
int distSq(const Point& p1, const Point& p2)
{
    return (p1.x - p2.x) * (p1.x - p2.x) +
        (p1.y - p2.y) * (p1.y - p2.y);
}

// To find orientation of ordered triplet (p, q, r).
// The function returns following values
// 0 --> p, q and r are collinear
// 1 --> Clockwise
// 2 --> Counterclockwise
int orientation(const Point& p, const Point& q, const Point& r)
{
    double val = (q.y - p.y) * (r.x - q.x) -
        (q.x - p.x) * (r.y - q.y);

    // collinear return 0
    return (abs(val) < 0.001) ? 0 : (val > 0.001) ? 1 : 2; // clock or counterclock wise
}

// A function used by library function qsort() to sort an array of
// points with respect to the first point
int compare(const void* vp1, const void* vp2)
{
    Point* p1 = (Point*)vp1;
    Point* p2 = (Point*)vp2;

    // Find orientation
    int o = orientation(p0, *p1, *p2);

    return (o == 0) ? ( (distSq(p0, *p2) >= distSq(p0, *p1)) ? -1 : 1) : ((o == 2) ? -1 : 1);
}

// Prints convex hull of a set of n points.
std::vector<Point> GramconvexHull(Point* points, const long long& n)
{
    if (points == NULL || n < 1) throw "wrong input";
    //long long n = points.size();
    // Find the bottommost point
    double ymin = points[0].y; long long min = 0;
    for (long long i = 1; i < n; ++i)
    {
        double y = points[i].y;

        // Pick the bottom-most or choose the left
        // most point in case of tie
        if ((y < ymin) || (ymin == y &&
            points[i].x < points[min].x))
            ymin = points[i].y, min = i;
    }

    // Place the bottom-most point at first position
    swap(points[0], points[min]);

    // Sort n-1 points with respect to the first point.
    // A point p1 comes before p2 in sorted output if p2
    // has larger polar angle (in counterclockwise
    // direction) than p1
    p0 = points[0];
    qsort(&points[1], n - 1, sizeof(Point), compare);

    // If two or more points make same angle with p0,
    // Remove all but the one that is farthest from p0
    // Remember that, in above sorting, our criteria was
    // to keep the farthest point at the end when more than
    // one points have same angle.
    long long m = 1; // Initialize size of modified array
    for (long long i = 1; i < n; ++i)
    {
        // Keep removing i while angle of i and i+1 is same
        // with respect to p0
        while (i < n - 1 && orientation(p0, points[i],
            points[i + 1]) == 0)
            i++;

        points[m] = points[i];
        m++;  // Update size of modified array
    }

    // If modified array of points has less than 3 points,
    // convex hull is not possible
    if (m < 3) return std::vector<Point>(points, points + m);

    // Create an empty stack and push first three points
    // to it.
    std::stack<Point> S;
    S.push(points[0]);
    S.push(points[1]);
    S.push(points[2]);

    // Process remaining n-3 points
    for (long long i = 3; i < m; ++i)
    {
        // Keep removing top while the angle formed by
        // points next-to-top, top, and points[i] makes
        // a non-left turn
        while (S.size() > 1 && orientation(nextToTop(S), S.top(), points[i]) != 2)
            S.pop();
        S.push(points[i]);
    }

    std::vector<Point> answer;
    // Now stack has the output points
    while (!S.empty())
    {
        answer.push_back(S.top());
        S.pop();
    }
    return answer;
}




//===========================================================================



// Define Infinite (Using INT_MAX caused overflow problems)


std::vector<Point> JarvisconvexHull(std::vector<Point>& points)
{
    long long n = points.size();
    // There must be at least 3 points
    if (n < 3) 
        return points;


    //========================================
    double ymin = points[0].y; long long min = 0;
    for (long long i = 1; i < n; ++i)
    {
        double y = points[i].y;

        // Pick the bottom-most or choose the left
        // most point in case of tie
        if ((y < ymin) || (ymin == y &&
            points[i].x < points[min].x))
            ymin = points[i].y, min = i;
    }

    // Place the bottom-most point at first position
    swap(points[0], points[min]);

    // Sort n-1 points with respect to the first point.
    // A point p1 comes before p2 in sorted output if p2
    // has larger polar angle (in counterclockwise
    // direction) than p1
    p0 = points[0];
    qsort(&points[1], n - 1, sizeof(Point), compare);

    //=======================================

    // Initialize Result
    long long* next;
    if (!(next = new long long[n])) throw "memory limit";

    //nessesary for printing results
    for (long long i = 0; i < n; ++i)
        next[i] = -1;

    // Find the leftmost point
    long long l = 0;
    for (long long i = 1; i < n; ++i)
        l = (points[i].x < points[l].x) ? i : l;



    // Start from leftmost point, keep moving counterclockwise
    // until reach the start point again
    long long p = l, q;
    do
    {
        // Search for a point 'q' such that orientation(p, i, q) is
        // counterclockwise for all points 'i'
        q = (p + 1) % n;
        for (long long i = 0; i < n; ++i)
            q = (orientation(points[p], points[i], points[q]) == 2)?  i : q;
        //when orientation is counterclockwise swap points(next point has more angle)

        p = next[p] = q; // Add q to result as a next point of p
        // q; // Set p as q for next iteration
    } while (p != l);

    std::vector<Point> answer;
    // Result
    for (long long i = 0; i < n; ++i)
    {
        if (next[i] != -1)
            answer.push_back(points[i]);
    }

    delete[]next;
    return answer;
}

std::vector<Point> convexHull(Point* const points, const long long& len) {
    if (points == NULL || len < 1) throw "wrong input";

    if (len < 3)
        return std::vector<Point>(points,points + len);
    //put n = sqrt(len) 
    //[len/n] groups
    long long n = (long long)ceil(sqrt(len) - 1);

    /*
    std::cout << "\nenter n\n";
    std::cin >> n;
    */
    
    //uncomment to use manual input n

    std::cout << std::endl << "n = " << n << std::endl;

    std::vector<Point> tmp_vect;
    std::vector<Point> tmp;
    long long len_tmp = len / n;
    long long len_tmp1 = 0;
    while (len_tmp1 + len_tmp <= len) {
        tmp = GramconvexHull(&points[len_tmp1], len_tmp);//subset of points
        len_tmp1 += len_tmp;
        tmp_vect.insert(tmp_vect.end(), tmp.begin(), tmp.end());
    }
    //if len/n has residue we should push points, which are not consisted in any subsets
    for (long long i = len_tmp1; i < len; ++i) {
        tmp_vect.push_back(points[i]);
    }
    return JarvisconvexHull(tmp_vect);
}

// Driver program to test above functions
int main()
{
    srand(time(NULL));
    const int RANDVALUE = 10000;
    
    unsigned long long int len = 0;
    std::cout << "enter amount of 2d points" << std::endl;
    std::cin >> len;
    Point* points = new Point[len];
    for (unsigned long long int i = 0; i < len; ++i) {
        double x, y;
        //y = (rand() % RANDVALUE - RANDVALUE / 2) * sin(rand() % RANDVALUE), x = (rand() % RANDVALUE - RANDVALUE / 2) * cos(rand() % RANDVALUE); //uncoment random input
        
        std::cin >> x >> y; 
        points[i]=Point(x, y);
    }
    float timer1 = std::clock();
    std::cout << "The points in the convex hull are: " << std::endl;

    std::vector<Point> answer = convexHull(points, len);
    std::cout << std::endl << "time: " << (float)(clock() - timer1) / CLOCKS_PER_SEC << std::endl;
    for (int i = 0; i < answer.size(); ++i) {
        std::cout << "( " << answer[i].x << " , " << answer[i].y << " )" << std::endl;
    }
    delete[]points;
    return 0;
}
