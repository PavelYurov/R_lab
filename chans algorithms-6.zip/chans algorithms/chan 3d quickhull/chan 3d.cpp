﻿#include <iostream>
#include <stack>
#include <stdlib.h>


#include <algorithm>
#include <random>

#include<time.h>
#include<vector>

#include"incremental algorithm/incremental.h"
#include"incremental algorithm/quickhull algorithm/quickhull-master/QuickHull_comp.hpp"


struct Point3D_pair { //edge
    Point3D a, b;
    Point3D_pair() {
        a = Point3D();
        b = Point3D();
    }
    Point3D_pair(const Point3D& a, const Point3D& b) {
        this->a = a; this->b = b;
    }
    bool operator==(const Point3D_pair& p) {
        return (a == p.a && b == p.b) || (a == p.b && b == p.a);
    }
};

struct Point3D_tri : public Point3D_pair { //face
    Point3D c;
    Point3D_tri() : Point3D_pair() {
        c = Point3D();
    }
    Point3D_tri(const Point3D& a, const Point3D& b, const Point3D& c) : Point3D_pair(a, b) {
        this->c = c;
    }
    Point3D_tri(const Point3D_pair& pair) : Point3D_pair(pair.a, pair.b) {
        this->c = Point3D(INFINITY, INFINITY, INFINITY);
    }
    bool operator==(const Point3D_tri& p) {
        return (a == p.a) && ((b == p.b && c == p.c)
            || (b == p.c && c == p.b))
            || (a == p.b) && ((b == p.a && c == p.c)
                || (b == p.c && c == p.a))
            || (a == p.c) && ((b == p.b && c == p.a)
                || (b == p.a && c == p.b));
    }
};


struct vector3d { //vector created by 2 points
    double x, y, z;
    vector3d(const Point3D& a, const Point3D& b) {
        x = b.x - a.x;
        y = b.y - a.y;
        z = b.z - a.z;
    }
    vector3d(const double& x, const double& y, const double& z) {
        this->x = x;
        this->y = y;
        this->z = z;

    }
    double operator/(const vector3d& p) { //scalar product vectors
        return x * p.x + y * p.y + z * p.z;
    }
    double operator/(const vector3d& p) const { //scalar product vectors
        return x * p.x + y * p.y + z * p.z;
    }
    vector3d operator*(const vector3d& v) { //vector product vectors
        return vector3d(y * v.z - z * v.y, z * v.x - x * v.z, x * v.y - y * v.x);
    }
    vector3d operator*(const vector3d& v) const { ///vector product vectors
        return vector3d(y * v.z - z * v.y, z * v.x - x * v.z, x * v.y - y * v.x);
    }
    double lenght() {
        return sqrt(x * x + y * y + z * z);
    }
    double lenght() const {
        return sqrt(x * x + y * y + z * z);
    }
};

double Area(const Point3D& a, const Point3D& b, const Point3D& c) {
    vector3d tmp = vector3d(a, b) * vector3d(a, c);
    return tmp.lenght() * 0.5;
}

double Volume(const Point3D& a, const Point3D& b, const Point3D& c, const Point3D& d) {
    vector3d tmp = vector3d(a, b) * vector3d(a, c);
    return (vector3d(a, d) / tmp) * 0.166666667; //volume of tetrahedron
}


double angle(const vector3d& a, const vector3d& b) {
    return acos((a / b) / (a.lenght() * b.lenght()));
}

Point3D PivotAroundEdge(const Point3D& q0, const Point3D& q1, const std::vector<Point3D>& P, const Point3D& start_pnt) {
    Point3D p = start_pnt;
    double area = Area(q0, q1, p), volume, area_tmp;
    for (int i = 0; i < P.size(); ++i) {
        volume = Volume(q0, q1, p, P[i]);
        if (volume < 0) {
            p = P[i];
            area = Area(q0, q1, p);
        }
        else if (volume == 0) {
            area_tmp = Area(q0, q1, P[i]);
            if (area_tmp > area && !(p == start_pnt)) {
                if (angle(vector3d(q0, q1), vector3d(q0, p)) + angle(vector3d(q0, q1), vector3d(q0, P[i])) - angle(vector3d(q0, p), vector3d(q0, P[i])) > 0.1) {
                    p = P[i];
                    area = area_tmp;
                }
            }
            else if (p == start_pnt && !(P[i] == q1 || P[i] == q0 || P[i] == start_pnt) &&
                angle(vector3d(q0, q1), vector3d(q0, p)) + angle(vector3d(q0, q1), vector3d(q0, P[i])) - angle(vector3d(q0, p), vector3d(q0, P[i])) < 0.1) {
                p = P[i];
                area = area_tmp;
            }
        }
    }
    return p;
}


Point3D_tri FindEdgeOnHull(const std::vector<Point3D>& P) {
    //find most bottom most far most back point
    Point3D p = P[0];
    Point3D p_tmp = P[0];
    for (int i = 1; i < P.size(); ++i) {
        p = ((p.z > P[i].z) || ((p.z == P[i].z) && ((p.y > P[i].y) || (p.y == P[i].y && p.x > P[i].x)))) ? P[i] : p;
    }
    //find most top most close most front point
    //temporery point for searching starting face
    for (int i = 1; i < P.size(); ++i) {
        p_tmp = ((p.z < P[i].z) || ((p.z == P[i].z) && ((p.y < P[i].y) || (p.y == P[i].y && p.x < P[i].x)))) ? P[i] : p_tmp;
    }

    Point3D q = p;
    for (int i = 0; i < P.size(); ++i) {
        q = (q.z == P[i].z && q.y == P[i].y && q.x < P[i].x) ? P[i] : q;
    }
    q = PivotAroundEdge(p, (q == p) ? p + Point3D(1, 0, 0) : q, P, p_tmp);

    return Point3D_tri(p, q, p_tmp);
}


Point3D_tri FindTriangleOnHull(const std::vector<Point3D>& P) {
    Point3D_tri tmp = FindEdgeOnHull(P);
    tmp.c = PivotAroundEdge(tmp.a, tmp.b, P, tmp.c);
    return tmp;
}

bool NotProcessed(const Point3D_tri& e, const std::vector<Point3D_tri>& Proc) {
    for (int i = 0; i < Proc.size(); ++i) {
        if ((e.a == Proc[i].a && e.b == Proc[i].b) || (e.b == Proc[i].a && e.a == Proc[i].b))
            return false;
    }
    return true;
}

template<class T>
void add_to_vector(std::vector<T>& H, const T& t) {
    for (int i = 0; i < H.size(); ++i) {
        if (H[i] == t) return;
    }
    H.push_back(t);
}

std::vector<Point3D_tri> GiftWrap(const std::vector<Point3D>& P) {
    Point3D_tri t = FindTriangleOnHull(P);

    std::vector<Point3D_tri> Q;
    Q.push_back(Point3D_tri(t.a, t.b, t.c));
    Q.push_back(Point3D_tri(t.c, t.b, t.a));
    Q.push_back(Point3D_tri(t.a, t.c, t.b));

    std::vector<Point3D_tri> H;
    H.push_back(t);

    std::vector<Point3D_tri> Proc;
    Point3D_tri e;
    Point3D_tri tmp;

    while (Q.size() != 0) {
        e = Q.back();
        Q.pop_back();
        if (NotProcessed(e, Proc)) {
            t = Point3D_tri(e.a, e.b, PivotAroundEdge(e.a, e.b, P, e.c));
            add_to_vector<Point3D_tri>(H, t);

            tmp = Point3D_tri(t.a, t.b, t.c);
            Q.push_back(tmp);
            tmp = Point3D_tri(t.c, t.b, t.a);
            Q.push_back(tmp);
            tmp = Point3D_tri(t.a, t.c, t.b);
            Q.push_back(tmp);

            Proc.push_back(e);
        }
    }
    return H;
}
//======================================================

std::vector<Point3D_tri> 
convexHull(Point3D* Point3Ds) {
    const long long len = _msize(Point3Ds) / sizeof(Point3D);
    
    const long long n = (long long)pow(2,pow(2,ceil(log(log((len))))));

    std::cout << std::endl << "n = " << n << std::endl;
    //std::cout << "enter n: ";
    //std::cin >> n;
    //uncomment for manual input n
    std::vector<Point3D> tmp_vect;
    long long len_tmp = len / n;
    long long len_tmp1 = 0;

    quickhull::QuickHull<double> qh;
    quickhull::ConvexHull<double> hull;
    quickhull::VertexDataSource<double> tmp;

    while (len_tmp1 + len_tmp <= len) {
        
        hull = qh.getConvexHull(&Point3Ds[len_tmp1], len_tmp, true, false);
        tmp = hull.getVertexBuffer();
        tmp_vect.insert(tmp_vect.end(), tmp.begin(), tmp.end());
        len_tmp1 += len_tmp;
    }
    for (long long i = len_tmp1; i < len; ++i) {
        tmp_vect.push_back(Point3Ds[i]);
    }

    return GiftWrap(tmp_vect);
}

//======================================================


int main()
{
    srand(time(NULL));
    const int RANDVALUE = 10000;

    


    unsigned long long int len = 0;
    std::cout << "enter amount of 3d Point3Ds" << std::endl;
    std::cin >> len;
    Point3D* Point3Ds = new Point3D[len];
    for (unsigned long long int i = 0; i < len; ++i) {
        double x, y, z;
        //double  y = (rand() % RANDVALUE - RANDVALUE / 2) , x = (rand() % RANDVALUE - RANDVALUE / 2) , z = (rand() % RANDVALUE - RANDVALUE / 2);
        

        std::cin >> x >> y >> z;
        Point3Ds[i] = Point3D(x, y, z);
    }
    
    std::cout << "The Point3Ds in the convex hull are: " << std::endl;
    float timer3 = std::clock();

    auto hull = convexHull(Point3Ds);

    std::cout << std::endl << "time: " << (float)(clock() - timer3) / CLOCKS_PER_SEC << std::endl;
    for (int i = 0; i < hull.size(); ++i) {
        std::cout << "( " << hull[i].a.x << " , " << hull[i].a.y << " , " << hull[i].a.z << " ) ";
        std::cout << "( " << hull[i].b.x << " , " << hull[i].b.y << " , " << hull[i].b.z << " ) ";
        std::cout << "( " << hull[i].c.x << " , " << hull[i].c.y << " , " << hull[i].c.z << " )" << std::endl;
        
    }

    delete[]Point3Ds;
    return 0;
}

