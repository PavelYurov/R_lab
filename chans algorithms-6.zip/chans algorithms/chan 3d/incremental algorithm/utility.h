#include <vector>
#include "quickhull algorithm/quickhull-master/Structs/Vector3.hpp"
#define Point3D quickhull::Vector3<double>

typedef std::vector<Point3D> PointStack;

struct point_hash
{
  std::size_t operator() (const Point3D& p) const
  {
      std::string sx, sy, sz;
      sx = std::to_string(p.x);
      sy = std::to_string(p.y);
      sz = std::to_string(p.z);
      return std::hash<std::string>{}(sx+sy+sz);
  }
};
