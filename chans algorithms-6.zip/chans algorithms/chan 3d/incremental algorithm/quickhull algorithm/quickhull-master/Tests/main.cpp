namespace quickhull {
	namespace tests {
		int run();
	}
}

int main(int, char** argv) {
	return quickhull::tests::run();
}
